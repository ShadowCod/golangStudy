package conversions

type Units string

const Bits = Units("bits")
